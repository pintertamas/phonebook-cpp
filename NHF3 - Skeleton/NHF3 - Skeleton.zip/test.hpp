//
// Created by Tomi on 27/04/2020.
//

#ifndef MY_AWESOME_PHONEBOOK_TEST_HPP
#define MY_AWESOME_PHONEBOOK_TEST_HPP

void test_1();
void test_2();

#endif //MY_AWESOME_PHONEBOOK_TEST_HPP
